package org.scoula.security.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

// 보안 필터 등록하는 클래스 상속
public class SecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}